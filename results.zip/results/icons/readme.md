Icônes pour les listes de résultats ou notices détaillées

Expression - type de contenu :
* Texte noté
* Musique exécutée
* Image fixe
* spectacle
* Texte noté. Image fixe
* Image animée
* Parole énoncée
* jeu vidéo
* programme
* émission radiophonique
* film
